package com.example.assent.assent_Backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AssentBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
