package com.example.assent.assent_Backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AssentBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(AssentBackendApplication.class, args);
	}

}
